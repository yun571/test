package com.example.test.utils

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import com.example.test.model.Block
import com.example.test.model.Data
import com.example.test.model.MusicInfo
import java.util.*
import kotlin.collections.ArrayList

object SharedPre {

    /**
     * 保存初始箭头位置
     */
    fun saveInitBlockData(context: Context, initBlockData: List<Int>) {
        val preferences = context.getSharedPreferences("gamedata", AppCompatActivity.MODE_PRIVATE)
        val editor = preferences.edit()
        editor.putInt("initBlockPosL",initBlockData[0])
        editor.putInt("initBlockPosT",initBlockData[1])
        editor.putInt("initBlockPosR",initBlockData[2])
        editor.putInt("initBlockPosB",initBlockData[3])
        editor.commit()
    }

    /**
     * 获取初始箭头位置
     */
    fun getInitBlockData(context: Context):ArrayList<Int> {
        val preferences = context.getSharedPreferences("gamedata", AppCompatActivity.MODE_PRIVATE)
        val list = ArrayList<Int>()
        list.add(preferences.getInt("initBlockPosL",0))
        list.add(preferences.getInt("initBlockPosT",0))
        list.add(preferences.getInt("initBlockPosR",0))
        list.add(preferences.getInt("initBlockPosB",0))
        return list
    }

    /**
     * 清空SharedPreferences("gamedata")
     */
    fun clearSharedPre(context: Context) {
        val preferences = context.getSharedPreferences("gamedata", AppCompatActivity.MODE_PRIVATE)
        val editor = preferences.edit()
        editor.clear()
        editor.commit()
    }

    /**
     * 保存reload标志
     */
    fun saveDataFlag(context: Context, flag: Boolean) {
        val preferences = context.getSharedPreferences("gamedata", AppCompatActivity.MODE_PRIVATE)
        val editor = preferences.edit()
        editor.putBoolean("dataFlag", flag)
        editor.commit()
    }

    /**
     * 获取reload标志
     */
    fun getDataFlag(context: Context): Boolean {
        val preferences = context.getSharedPreferences("gamedata", AppCompatActivity.MODE_PRIVATE)
        return preferences.getBoolean("dataFlag", false)
    }

    /**
     * 保存游戏数据
     */
    fun saveGameData(context: Context, data: Data) {
        val preferences = context.getSharedPreferences("gamedata", AppCompatActivity.MODE_PRIVATE)
        val editor = preferences.edit()
        editor.putString("dataScore", data.dataScore)
        editor.putInt("timeCount", data.timeCount)
        editor.putBoolean("dataFlag", data.dataFlag)
        editor.putFloat("blockPosL", data.blockPos[0])
        editor.putFloat("blockPosT", data.blockPos[1])
        editor.putFloat("blockPosR", data.blockPos[2])
        editor.putFloat("blockPosB", data.blockPos[3])
        editor.putInt("blockQueueSize", data.blockQueue.size)
        for (i in 0 until data.blockQueue.size) {
            val block = data.blockQueue.poll()
            editor.putInt("blockQueue$i" + "_direction", block.direction)
            editor.putInt("blockQueue$i" + "_speed", block.speed)
            editor.putBoolean("blockQueue$i" + "_alive", block.alive)
        }
        editor.putInt("musicId" , data.musicInfo.id)
        editor.putString("SingNamer",data.musicInfo.singNamer)
        editor.putString("singer",data.musicInfo.singer)
        editor.putString("time",data.musicInfo.time)
        editor.putString("path",data.musicInfo.path)
        editor.commit()
    }

    /**
     * 获取游戏数据
     */
    fun getGameData(context: Context): Data {
        var block: Block
        val preferences = context.getSharedPreferences("gamedata", AppCompatActivity.MODE_PRIVATE)
        val dataScore = preferences.getString("dataScore", "0")
        val timeCount = preferences.getInt("timeCount", 0)
        val dataFlag = preferences.getBoolean("dataFlag", false)
        val blockPosL = preferences.getFloat("blockPosL", 0f)
        val blockPosT = preferences.getFloat("blockPosT", 0f)
        val blockPosR = preferences.getFloat("blockPosR", 0f)
        val blockPosB = preferences.getFloat("blockPosB", 0f)
        val array = FloatArray(4)
        array[0] = blockPosL
        array[1] = blockPosT
        array[2] = blockPosR
        array[3] = blockPosB
        val size = preferences.getInt("blockQueueSize", 0)
        val blockQueue: Queue<Block> = LinkedList<Block>()
        for (i in 0 until size) {
            val direction = preferences.getInt("blockQueue$i" + "_direction", 0)
            val speed = preferences.getInt("blockQueue$i" + "_speed", 0)
            val alive = preferences.getBoolean("blockQueue$i" + "_alive", false)
            block = Block(direction, speed, alive)
            blockQueue.offer(block)
        }
        val musicId = preferences.getInt("musicId" , 0)
        val SingNamer = preferences.getString("SingNamer", "")
        val singer = preferences.getString("singer", "")
        val time = preferences.getString("time","")
        val path = preferences.getString("path","")
        val musicInfo = MusicInfo(musicId,SingNamer,singer,time,path)
        return Data(dataScore!!, timeCount, dataFlag, array, blockQueue, musicInfo)
    }
}