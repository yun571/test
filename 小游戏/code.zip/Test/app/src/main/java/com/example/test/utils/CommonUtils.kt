package com.example.test.utils

import android.content.Context
import android.os.Build
import com.example.test.model.Language
import org.litepal.LitePal
import org.litepal.extension.deleteAll
import org.litepal.extension.find
import org.litepal.extension.findAll
import org.litepal.extension.isExist
import java.util.*

object CommonUtils {
    /**
     * 设置语言
     */
    fun configLanguage(mContext: Context, language: String) {
        val config = mContext.resources.configuration
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            if (language == "CHINESE") {
                config.locale = Locale.SIMPLIFIED_CHINESE
            } else if (language == "ENGLISH") {
                config.locale = Locale.US
            }
        } else {
            if (language == "CHINESE") {
                config.locale = Locale.CHINESE
            } else if (language == "ENGLISH") {
                config.locale = Locale.ENGLISH
            } else {
                config.locale = Locale.CHINESE
            }
        }
        saveLanguage(language)
        mContext.resources.updateConfiguration(config, null)
    }

    /**
     * 保存语言设置
     */
    private fun saveLanguage(language: String) {
        val lan = Language(language)
        LitePal.deleteAll<Language>()
        lan.save()
    }

    /**
     * 获取语言
     */
    fun getLanguage(mContext: Context,language: String): String {
        var lan = language
        if (LitePal.isExist<Language>() && LitePal.findAll<Language>() != null) {
            val la = LitePal.findAll<Language>()
            for(i in la){
                lan = i.language
            }
        }
        return lan
    }
}