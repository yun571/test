package com.example.test.listener

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.util.Log

class PowerOffListener(context: Context) {
    private val mContext: Context
    private val mFilter: IntentFilter
    private var mListener: onPowerOffListener? = null
    private var mRecevier: InnerReceiver? = null

    // 回调接口
    interface onPowerOffListener {
        //回调
        fun onPowerOffListener()

    }

    /**
     * 设置监听
     *
     */
    fun setOnPowerOffListener(listener: onPowerOffListener?) {
        mListener = listener
        mRecevier = InnerReceiver()
    }

    /**
     * 开始监听，注册广播
     */
    fun startWatch() {
        if (mRecevier != null) {
            mContext.registerReceiver(mRecevier, mFilter)
        }
    }

    /**
     * 停止监听，注销广播
     */
    fun stopWatch() {
        if (mRecevier != null) {
            mContext.unregisterReceiver(mRecevier)
        }
    }

    /**
     * 广播接收者
     */
    internal inner class InnerReceiver : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent) {
            val action = intent!!.action
            if(action != null) {
                if (action == "android.intent.action.ACTION_SHUTDOWN") {
                    mListener!!.onPowerOffListener()
                    Log.d("action","关机")
                }
            }
        }
    }

    companion object {
        const val TAG = "OnPowerOffListener"
    }

    init {
        mContext = context
        mFilter = IntentFilter()
    }
}