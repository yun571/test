package com.example.test.service

import android.R.attr.path
import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.annotation.RequiresApi
import com.example.test.model.MusicInfo
import java.io.IOException


class MusicService(val musicInfo: MusicInfo): Service() {
    var mediaPlayer: MediaPlayer? = null
    override fun onBind(intent: Intent?): IBinder? {
        return MyBinder();
    }

    inner class MyBinder : Binder() {
        //判断是否处于播放状态
        val isPlaying: Boolean
            get() = mediaPlayer!!.isPlaying

        //播放或暂停歌曲
        fun play() {
            if (mediaPlayer != null && !mediaPlayer!!.isPlaying) {
                mediaPlayer!!.start()
            }
            Log.e("服务", "播放音乐")
        }

        @RequiresApi(Build.VERSION_CODES.O)
        private fun resume(time: Long){
            if (mediaPlayer != null && !mediaPlayer!!.isPlaying) {
                mediaPlayer!!.seekTo(time, MediaPlayer.SEEK_CLOSEST)
                mediaPlayer!!.start()
            }
        }

        fun pause(){
            if (mediaPlayer != null && mediaPlayer!!.isPlaying) {
                mediaPlayer!!.pause()
            }
        }

        fun stop(){
            if (mediaPlayer != null && mediaPlayer!!.isPlaying) {
                mediaPlayer!!.stop()
            }
        }

        //返回歌曲的长度，单位为毫秒
        val duration: Int
            get() = mediaPlayer!!.duration

        //返回歌曲目前的进度，单位为毫秒
        val currenPostion: Int
            get() = mediaPlayer!!.currentPosition

        //设置歌曲播放的进度，单位为毫秒
        fun seekTo(mesc: Int) {
            mediaPlayer!!.seekTo(mesc)
        }
    }

    override fun onCreate() {
        super.onCreate()
        //这里只执行一次，用于准备播放器
        mediaPlayer = MediaPlayer()
        try {
            mediaPlayer!!.setDataSource(musicInfo.path)
            //准备资源
            mediaPlayer!!.prepare()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        Log.e("服务", "准备播放音乐")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return super.onStartCommand(intent, flags, startId)
    }
}