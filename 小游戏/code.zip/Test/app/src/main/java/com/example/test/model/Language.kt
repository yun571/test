package com.example.test.model

import org.litepal.crud.LitePalSupport

/**
 * @param language 语言
 */
class Language(val language:String):LitePalSupport()