package com.example.dateprovider

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    val AUTHORITY = "com.example.test.provider"
    val list = ArrayList<Record>()
    var adapter:ArrayAdapter<Record>? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        query.setOnClickListener {
            list.clear()
            val uri = Uri.parse("content://$AUTHORITY")
            val cursor = contentResolver.query(uri, null, null, null, null)
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    Log.d("cursor", cursor.getString(cursor.getColumnIndex("score")))
                    Log.d("cursor", cursor.getString(cursor.getColumnIndex("ranking")))
                    Log.d("cursor", cursor.getString(cursor.getColumnIndex("player_name")))
                    val record = Record(
                        cursor.getString(cursor.getColumnIndex("score")).toInt(),
                        cursor.getString(cursor.getColumnIndex("ranking")).toInt(),
                        cursor.getString(cursor.getColumnIndex("player_name"))
                    )
                    list.add(record)
                }
            }
            adapter?.notifyDataSetChanged()

        }
        //adapter = ArrayAdapter<Record>(this, android.R.layout.simple_list_item_1, list)
        adapter = MyAdapter(this,R.layout.item,list)
        listView.adapter = adapter

    }
}
