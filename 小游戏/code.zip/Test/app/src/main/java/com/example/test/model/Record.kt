package com.example.test.model

import org.litepal.crud.LitePalSupport

/**
 * @param score 分数
 * @param ranking 排名
 * @param player_name 玩家名字
 */
data class Record(val score: Int, var ranking: Int, val player_name:String):LitePalSupport()