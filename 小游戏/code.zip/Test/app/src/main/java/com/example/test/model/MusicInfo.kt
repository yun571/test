package com.example.test.model

import java.io.Serializable

class MusicInfo : Serializable {
    var id = 0
    var singNamer: String? = null
    var singer: String? = null
    var time: String? = null
    var path: String? = null

    constructor() {}
    constructor(
        id: Int,
        singNamer: String?,
        singer: String?,
        time: String?,
        path: String?
    ) {
        this.id = id
        this.singNamer = singNamer
        this.singer = singer
        this.time = time
        this.path = path
    }

    override fun toString(): String {
        return "MusicInfo{" +
                "id=" + id +
                ", singNamer='" + singNamer + '\'' +
                ", singer='" + singer + '\'' +
                ", time='" + time + '\'' +
                ", path='" + path + '\'' +
                '}'
    }
}