package com.example.test.broadcastReceiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log


class ShutdownBroadcastReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent) {  //即将关机时，要做的事情
        if (intent.action == ACTION_SHUTDOWN) {
            Log.d(
                TAG,
                "ShutdownBroadcastReceiver onReceive(), Do thing!"
            )
            context!!.unregisterReceiver(this)
        }
    }

    companion object {
        private const val TAG = "ShutdownBroadcast"
        private const val ACTION_SHUTDOWN = "android.intent.action.ACTION_SHUTDOWN"
    }
}