package com.example.test.listener

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.util.Log

class ScreenListener(context: Context) {
    private val mContext: Context = context
    private val mScreenOnFilter: IntentFilter
    private val mScreenOffFilter: IntentFilter
    private var mListener: OnScreenListener? = null
    private var mRecevier: ScreenListener.InnerReceiver? = null

    init {
        /* 屏幕唤醒时的广播 */
        mScreenOnFilter = IntentFilter("android.intent.action.SCREEN_ON")

        /* 机器锁屏时的广播 */
        mScreenOffFilter = IntentFilter("android.intent.action.SCREEN_OFF")
    }

    // 回调接口
    interface OnScreenListener {
        //亮屏
        fun onScreenOn()

        //熄屏
        fun onScreenOff()
    }

    /**
     * 设置监听
     *
     */
    fun setOnHomePressedListener(listener: OnScreenListener?) {
        mListener = listener
        mRecevier = InnerReceiver()
    }

    /**
     * 开始监听，注册广播
     */
    fun startWatch() {
        if (mRecevier != null) {
            mContext.registerReceiver(mRecevier, mScreenOnFilter)
            mContext.registerReceiver(mRecevier, mScreenOffFilter)
        }
    }

    /**
     * 停止监听，注销广播
     */
    fun stopWatch() {
        if (mRecevier != null) {
            mContext.unregisterReceiver(mRecevier)
        }
    }

    /**
     * 广播接收者
     */
    internal inner class InnerReceiver : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent!!.action
            if (action != null) {
                Log.d("action==>", action)
            }
            if(action != null) {
                if (action == "android.intent.action.SCREEN_ON") {
                    mListener!!.onScreenOn()
                } else if (action == "android.intent.action.SCREEN_OFF") {
                    mListener!!.onScreenOff()
                }
            }
        }

    }
}