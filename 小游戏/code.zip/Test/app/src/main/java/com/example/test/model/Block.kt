package com.example.test.model

/**
 * @param direction  0->上 1->下 2->左 3->右
 * @param speed 速度
 * @param alive 是否被消除
 */

data class Block(val direction: Int, var speed: Int, var alive: Boolean = false)