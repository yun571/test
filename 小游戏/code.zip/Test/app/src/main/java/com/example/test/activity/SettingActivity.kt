package com.example.test.activity

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.test.R
import com.example.test.model.Language
import com.example.test.utils.CommonUtils
import kotlinx.android.synthetic.main.activity_setting.*
import org.jetbrains.anko.startActivity
import org.litepal.LitePal

class SettingActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)
        tvChinese.setOnClickListener(this)
        tvEnglish.setOnClickListener(this)
    }


    override fun onClick(v: View) {
        when (v.id) {
            R.id.tvChinese -> {
                CommonUtils.configLanguage(this, "CHINESE")
                this.finish()
            }
            R.id.tvEnglish -> {
                CommonUtils.configLanguage(this, "ENGLISH")
                this.finish()
            }
        }
    }
}