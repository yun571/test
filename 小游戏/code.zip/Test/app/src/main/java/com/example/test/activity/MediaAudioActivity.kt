package com.example.test.activity

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.icu.text.SimpleDateFormat
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemClickListener
import android.widget.ListView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.test.R
import com.example.test.adapter.MusicAdapter
import com.example.test.model.MusicInfo
import org.jetbrains.anko.toast
import java.util.*

class MediaAudioActivity : AppCompatActivity() {
    private var lv: ListView? = null
    private val mList: MutableList<MusicInfo> = ArrayList()
    private var adapter: MusicAdapter? = null


    @RequiresApi(api = Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!verifyStoragePermissions(this)) {
            toast("请打开相关权限设置!")
            this.finish()
        } else {
            setContentView(R.layout.activity_media_audio)
            lv = findViewById<View>(R.id.music_lv) as ListView
            adapter = MusicAdapter(this, mList)
            lv!!.adapter = adapter
            loadLocalData()
            lv!!.onItemClickListener = object : OnItemClickListener {
                override fun onItemClick(
                    adapterView: AdapterView<*>?,
                    view: View,
                    i: Int,
                    l: Long
                ) {
                    val info = mList[i]
                    val intent = Intent(this@MediaAudioActivity, GameActivity::class.java)
                    intent.putExtra("musicInfo", info)
                    startActivity(intent)
                }
            }
        }
    }

    /**
     * 获取本地音频文件
     */
    @RequiresApi(api = Build.VERSION_CODES.N)
    private fun loadLocalData() {
        val resolver = contentResolver
        val musicUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val cursor = resolver.query(musicUri, null, null, null, null)
        var id = 0
        while (cursor!!.moveToNext()) {
            val title =
                cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE))
            val display_name =
                cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME))
            val singer =
                cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST))
            val path =
                cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATA))
            val duration =
                cursor.getLong(cursor.getColumnIndex(MediaStore.Audio.Media.DURATION))
            val sdf = SimpleDateFormat("mm:ss")
            val time = sdf.format(Date(duration))
            id++
            val idStr = id
            val info = MusicInfo(idStr, title, singer, time, path)
            mList.add(info)
        }
        adapter!!.notifyDataSetChanged()
    }


    companion object {
        //先定义
        private const val REQUEST_EXTERNAL_STORAGE = 1
        private val PERMISSIONS_STORAGE = arrayOf(
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE"
        )
    }

    /**
     *权限校验与申请
     * @param activity
     * @return Boolean
     */
    private fun verifyStoragePermissions(activity: Activity?): Boolean {
        try {
            //检测是否有写的权限
            val permission = ActivityCompat.checkSelfPermission(
                activity!!,
                "android.permission.WRITE_EXTERNAL_STORAGE"
            )
            if (permission != PackageManager.PERMISSION_GRANTED) {
                // 没有写的权限，去申请写的权限，会弹出对话框
                ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
                )
                return false
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return true
    }
}