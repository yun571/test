package com.example.test.listener

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.util.Log


class HomeListener(context: Context) {
    private val mContext: Context
    private val mFilter: IntentFilter
    private var mListener: OnHomePressedListener? = null
    private var mRecevier: InnerReceiver? = null

    // 回调接口
    interface OnHomePressedListener {
        //home回调
        fun onHomePressed()

        //任务回调
        fun onHomeLongPressed()
    }

    /**
     * 设置监听
     *
     */
    fun setOnHomePressedListener(listener: OnHomePressedListener?) {
        mListener = listener
        mRecevier = InnerReceiver()
    }

    /**
     * 开始监听，注册广播
     */
    fun startWatch() {
        if (mRecevier != null) {
            mContext.registerReceiver(mRecevier, mFilter)
        }
    }

    /**
     * 停止监听，注销广播
     */
    fun stopWatch() {
        if (mRecevier != null) {
            mContext.unregisterReceiver(mRecevier)
        }
    }

    /**
     * 广播接收者
     */
    internal inner class InnerReceiver : BroadcastReceiver() {
        val SYSTEM_DIALOG_REASON_KEY = "reason"
        val SYSTEM_DIALOG_REASON_GLOBAL_ACTIONS = "globalactions"
        val SYSTEM_DIALOG_REASON_RECENT_APPS = "recentapps"
        val SYSTEM_DIALOG_REASON_HOME_KEY = "homekey"
        override fun onReceive(context: Context?, intent: Intent) {
            val action = intent.action
            if (action == Intent.ACTION_CLOSE_SYSTEM_DIALOGS) {
                val reason = intent.getStringExtra(SYSTEM_DIALOG_REASON_KEY)
                if (reason != null) {
                    Log.d("reason==>",reason)
                }
                if (reason != null) {
                    Log.d("reason===>",reason)
                    if (mListener != null) {
                        when (reason) {
                            SYSTEM_DIALOG_REASON_HOME_KEY -> {
                                //home键
                                mListener!!.onHomePressed()
                            }
                            SYSTEM_DIALOG_REASON_RECENT_APPS -> {
                                //任务切换键
                                mListener!!.onHomeLongPressed()
                            }
                            "voiceinteraction" -> {
                                //长摁home键
                                Log.i("reason==>", "voiceinteraction");
                            }
                            "assist" -> {
                                //长摁home键
                                Log.i("reason==>", "assist");
                            }
                            "lock" -> {
                                // 锁屏
                                Log.i("reason==>", "lock");
                            }
                            "recentapps" -> {
                                //home键
                                mListener!!.onHomePressed()
                                Log.i("reason====>", "recentapps");
                            }
                        }
                    }
                }
            }
        }
    }

    companion object {
        const val TAG = "HomeListener"
    }

    init {
        mContext = context
        //找到intent的标识ACTION_CLOSE_SYSTEM_DIALOGS指示意思为：
        //广播行为：当用户操作请求临时退出当前对话框时发送广播
        mFilter = IntentFilter(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
    }
}