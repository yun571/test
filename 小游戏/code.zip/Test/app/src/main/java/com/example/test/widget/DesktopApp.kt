package com.example.test.widget

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.text.format.Time
import android.util.Log
import android.view.View
import android.widget.RemoteViews
import com.example.test.R
import com.example.test.activity.MainActivity
import com.example.test.service.AppWidgetUpdateService

class DesktopApp : AppWidgetProvider() {
    private val TAG = "DesktopApp"
    private var deskContext: Context? = null
    private var deskPendingIntent: PendingIntent? = null
    var SERVICE_INTENT: Intent? = null
    var a = 0
    var s = 0
    var arr = intArrayOf(
        R.drawable.pica_1,
        R.drawable.pika_2,
        R.drawable.pika_3,
        R.drawable.pika_4,
        R.drawable.pika_7,
        R.drawable.pika_8
    )
    var thread: Thread? = null
    var pendingIntent: PendingIntent? = null
    var intent1: Intent? = null
    var alarm: AlarmManager? = null
    @SuppressLint("ShortAlarm")
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        Log.d(TAG, "onUpdate")
        deskContext = context
        val intent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(context, 0, intent, 0)
        val appWidgetManager = AppWidgetManager.getInstance(context)
        // 加载指定界面布局文件，创建RemoteViews对象
        val remoteViews = RemoteViews(
            context.packageName,
            R.layout.my_widget
        )
        // 为show ImageView设置图片
        remoteViews.setImageViewResource(R.id.show, arr[0]) //设置小部件显示图标
        // 将AppWidgetProvider的子类实例包装成ComponentName对象
        remoteViews.setOnClickPendingIntent(R.id.show, pendingIntent)
        val componentName = ComponentName(
            context,
            DesktopApp::class.java
        )
        // 调用AppWidgetManager将remoteViews添加到ComponentName中
        appWidgetManager.updateAppWidget(componentName, remoteViews)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        Log.d(TAG, "onReceive")
    }

    //当第一个Widget被添加的时候调用
    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        Log.d(TAG, "onEnabled")
    }

    override fun onDeleted(
        context: Context,
        appWidgetIds: IntArray
    ) {
        super.onDeleted(context, appWidgetIds)
        Log.d(TAG, "onDeleted")
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        Log.d(TAG, "onDisabled")
    }
}