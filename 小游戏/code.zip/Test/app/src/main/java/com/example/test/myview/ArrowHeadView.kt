package com.example.test.myview

import android.content.Context
import android.graphics.Canvas
import android.view.View

class ArrowHeadView(context: Context?) : View(context) {

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        
    }
}