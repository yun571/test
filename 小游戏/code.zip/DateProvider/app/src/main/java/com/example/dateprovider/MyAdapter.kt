package com.example.dateprovider

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class MyAdapter(
    private val mContext: Context,
    private val resId: Int,
    private val list: List<Record>
) : ArrayAdapter<Record>(mContext, resId, list) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val record = getItem(position)
        val view = LayoutInflater.from(mContext).inflate(resId, parent, false)
        val name = view.findViewById<TextView>(R.id.name)
        val rank = view.findViewById<TextView>(R.id.rank)
        val score = view.findViewById<TextView>(R.id.score)
        name.text = record.player_name
        rank.text = record.ranking.toString()
        score.text = record.score.toString()
        return view
    }

    override fun getViewTypeCount(): Int {
        return super.getViewTypeCount()
    }

    override fun getItem(position: Int): Record {
        return list[position]
    }

    override fun getCount(): Int {
        return list.size
    }
}