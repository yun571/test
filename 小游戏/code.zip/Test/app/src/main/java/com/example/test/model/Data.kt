package com.example.test.model

import org.litepal.crud.LitePalSupport
import java.util.*

/**
 * @param dataScore 分数
 * @param timeCount 时间
 * @param dataFlag reload标志
 * @param blockPos 初始箭头位置
 * @param blockQueue 箭头队列
 * @param musicInfo 音频Bean类
 * @see LitePalSupport 数据库存储类
 */
data class Data(
    val dataScore: String,
    val timeCount: Int,
    val dataFlag: Boolean,
    val blockPos: FloatArray,
    val blockQueue: Queue<Block>,
    val musicInfo: MusicInfo
) : LitePalSupport() {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as Data

        if (!blockPos.contentEquals(other.blockPos)) return false
        if (blockQueue != other.blockQueue) return false

        return true
    }

    override fun hashCode(): Int {
        var result = blockPos.contentHashCode()
        result = 31 * result + blockQueue.hashCode()
        return result
    }
}