package com.example.test.dialog

class PauseMyDialog {
}