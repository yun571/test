package com.example.test.utils

import android.content.Context
import android.view.View
import android.view.ViewGroup.MarginLayoutParams
import android.widget.LinearLayout
import android.widget.RelativeLayout
import androidx.constraintlayout.widget.ConstraintLayout


object WidgetController {
    /*
     * 获取控件宽
     */
    fun getWidth(view: View): Int {
        val w: Int = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        val h: Int = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        view.measure(w, h)
        return view.measuredWidth
    }

    /*
     * 获取控件高
     */
    fun getHeight(view: View): Int {
        val w: Int = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        val h: Int = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        view.measure(w, h)
        return view.measuredHeight
    }

    fun getViewPosition(view: View): IntArray {
        val position = IntArray(2)
        view.getLocationInWindow(position)
        return position
    }

    /**
     * 根据手机的分辨率从 dp 的单位 转成为 px(像素)
     */
    fun dip2px(context:Context, dpValue:Float):Int {
        val scale = context.resources.displayMetrics.density;
        return (dpValue * scale + 0.5f).toInt()
    }

    /**
     * 根据手机的分辨率从 px(像素) 的单位 转成为 dp
     */
    fun px2dip(context:Context,pxValue:Float): Int {
        val scale = context.resources.displayMetrics.density;
        return (pxValue / scale + 0.5f).toInt()
    }

    /*
	 * 设置控件所在的位置X，并且不改变宽高，
	 * X为绝对位置，此时Y可能归0
	 */
    fun setLayoutX(view: View, x: Int) {
        val margin = MarginLayoutParams(view.layoutParams)
        margin.setMargins(x, margin.topMargin, x + margin.width, margin.bottomMargin)
        val layoutParams = ConstraintLayout.LayoutParams(margin)
        view.layoutParams = layoutParams
    }

    /*
	 * 设置控件所在的位置Y，并且不改变宽高，
	 * Y为绝对位置，此时X可能归0
	 */
    fun setLayoutY(view: View, y: Int) {
        val margin = MarginLayoutParams(view.layoutParams)
        margin.setMargins(margin.leftMargin, y, margin.rightMargin, y + margin.height)
        val layoutParams = ConstraintLayout.LayoutParams(margin)
        view.layoutParams = layoutParams
    }

    /*
	 * 设置控件所在的位置XY，并且不改变宽高，
	 * XY为绝对位置
	 */
    fun setLayout(view: View, x: Int, y: Int) {
        val margin = MarginLayoutParams(view.layoutParams)
        margin.setMargins(x, y, x + margin.width, y + margin.height)
        val layoutParams = ConstraintLayout.LayoutParams(margin)
        view.layoutParams = layoutParams
    }
}

