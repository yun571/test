package com.example.test.dialog

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import com.example.test.R
import kotlinx.android.synthetic.main.settlementdialog.*


class SettlementDialog(context: Context, val res: Int) : Dialog(context,res) {

    private var noOnclickListener //取消按钮被点击了的监听器
            : onNoOnclickListener? = null
    private var yesOnclickListener //确定按钮被点击了的监听器
            : onYesOnclickListener? = null

    /**
     * 设置取消按钮的监听
     */
    fun setNoOnclickListener(onNoOnclickListener: onNoOnclickListener) {
        noOnclickListener = onNoOnclickListener
    }

    /**
     * 设置确定按钮的监听
     */
    fun setYesOnclickListener(onYesOnclickListener: onYesOnclickListener?) {
        yesOnclickListener = onYesOnclickListener
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.settlementdialog);
        //按空白处不能取消动画
        setCanceledOnTouchOutside(false);
        //初始化界面控件的事件
        initEvent();
    }

    fun setTitle(str: String?) {
        if (str != null) {
            title.text = str
        }
    }

    fun setMessage(scoreData: Int?, rankData: String) {
        if (scoreData != null) {
            score.text = scoreData.toString()
        }
        if (rankData != null) {
            rank.text = rankData
        }
    }

    fun setYes(yesData: String?) {
        if (yesData != null) {
            yes.text = yesData
        }
    }


    /**
     * 初始化界面的确定和取消监听器
     */
    private fun initEvent() {
        //设置确定按钮被点击后，向外界提供监听
        yes.setOnClickListener { yesOnclickListener?.onYesClick() }
        //设置取消按钮被点击后，向外界提供监听
        no.setOnClickListener { noOnclickListener?.onNoClick() }
    }

    /**
     * 设置确定按钮和取消被点击的接口
     */
    interface onYesOnclickListener {
        fun onYesClick()
    }

    interface onNoOnclickListener {
        fun onNoClick()
    }
}