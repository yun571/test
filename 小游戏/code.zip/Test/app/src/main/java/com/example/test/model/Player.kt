package com.example.test.model

import com.example.test.model.Record

/**
 * @param player_id 玩家ID
 * @param player_name 玩家名字
 */
data class Player(val player_id:Int,val player_name:String)
