package com.example.test.activity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.test.R
import com.example.test.model.Language
import com.example.test.utils.CommonUtils
import kotlinx.android.synthetic.main.activity_main.*
import org.litepal.LitePal
import org.litepal.extension.findFirst


class MainActivity : AppCompatActivity() {

    var language = "CHINESE"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //如果MainActivity不在Task栈底则Finnish
        if (!this.isTaskRoot) {
            finish()
            return
        }

        language = CommonUtils.getLanguage(this, language)
        CommonUtils.configLanguage(this,language)
        //主页面布局
        setContentView(R.layout.activity_main)


    }

    override fun onResume() {
        super.onResume()
        //开始游戏
        start.setOnClickListener {
            val intent = Intent(this, MediaAudioActivity::class.java)
            startActivity(intent)
        }

        //游戏设置
        setting.setOnClickListener {
            val intent = Intent(this, SettingActivity::class.java)
            startActivity(intent)
        }

        //游戏帮助
        help.setOnClickListener {
            val intent = Intent(this, HelpActivity::class.java)
            startActivity(intent)
        }

        //退出游戏
        exit.setOnClickListener {
            this.finish()
        }

    }

    override fun onRestart() {
        super.onRestart()
        if(language != CommonUtils.getLanguage(this, language)) {
            language = CommonUtils.getLanguage(this, language)
            CommonUtils.configLanguage(this, language)
            recreate()
        }
    }

    override fun onStop() {
        super.onStop()

    }

}

