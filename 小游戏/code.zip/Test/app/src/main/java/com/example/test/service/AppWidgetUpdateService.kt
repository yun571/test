package com.example.test.service

import android.app.PendingIntent
import android.app.Service
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.SystemClock
import android.text.format.Time
import android.util.Log
import android.widget.RemoteViews
import com.example.test.R
import com.example.test.activity.MainActivity
import com.example.test.widget.DesktopApp
import kotlin.concurrent.thread
import kotlin.math.absoluteValue


class AppWidgetUpdateService : Service() {

    val arr = intArrayOf(
        R.drawable.pica_1,
        R.drawable.pika_2,
        R.drawable.pika_3,
        R.drawable.pika_4,
        R.drawable.pika_7,
        R.drawable.pika_8
    )
    var a = 0
    var s = 0
    var mContext: Context = this
    var thread: Thread? = null

    override fun onBind(p0: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        Log.d("APP_service", "onCreate")
        updateAllAppWidgets(this)
    }


    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("APP_service", "onStartCommand")
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (thread != null && thread!!.isAlive) {
            thread!!.destroy()
        }
        Log.d("APP_service", "onDestroy")
    }

    private fun updateAllAppWidgets(context: Context) {
        val intent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(context, 0, intent, 0)
        val appWidgetManager = AppWidgetManager.getInstance(context)
        // 加载指定界面布局文件，创建RemoteViews对象
        val remoteViews = RemoteViews(
            context.packageName,
            R.layout.my_widget
        )

        val time = Time();
        time.setToNow();
        a = time.toMillis(true).toInt().absoluteValue
            when (a % 6) {
                0 -> {
                    s = 0
                    a++
                }
                1 -> {
                    s = 1
                    a++
                }
                2 -> {
                    s = 2
                    a++
                }
                3 -> {
                    s = 3
                    a++
                }
                4 -> {
                    s = 4
                    a++
                }
                5 -> {
                    s = 5
                    a++
                }
            }
            Log.d("APP_a", a.toString())
            SystemClock.sleep(1000)

            // 为show ImageView设置图片
            remoteViews.setImageViewResource(R.id.show, arr[s]) //设置小部件显示图标

            // 将AppWidgetProvider的子类实例包装成ComponentName对象
            remoteViews.setOnClickPendingIntent(R.id.show, pendingIntent)
            val componentName = ComponentName(
                context,
                DesktopApp::class.java
            )
            // 调用AppWidgetManager将remoteViews添加到ComponentName中
            appWidgetManager.updateAppWidget(componentName, remoteViews)
        }
}