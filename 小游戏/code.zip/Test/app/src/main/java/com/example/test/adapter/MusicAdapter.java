package com.example.test.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.test.R;
import com.example.test.model.MusicInfo;

import java.util.List;


public class MusicAdapter extends BaseAdapter{
    private Context context;
    private List<MusicInfo> mlist;
    private LayoutInflater inflater;
    public MusicAdapter(Context context, List<MusicInfo> mlist) {
        this.context = context;
        this.mlist = mlist;
        inflater=LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return mlist.size();
    }

    @Override
    public Object getItem(int i) {
        return mlist.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        Hello hello=null;
        if (view==null){
            hello=new Hello();
            view=inflater.inflate(R.layout.item_music,viewGroup,false);
            hello.idTv=(TextView)view.findViewById(R.id.item_num);
            hello.titileTv=(TextView)view.findViewById(R.id.item_sing);
            hello.singerTv=(TextView)view.findViewById(R.id.item_singer);
            hello.timeTv=(TextView)view.findViewById(R.id.item_time);
            view.setTag(hello);
        }else {
            hello= (Hello) view.getTag();
        }
        MusicInfo musicInfo=mlist.get(i);
        hello.idTv.setText(musicInfo.getId()+"");
        hello.titileTv.setText(musicInfo.getSingNamer());
        hello.singerTv.setText(musicInfo.getSinger());
        hello.timeTv.setText(musicInfo.getTime());
        return view;
    }

    class Hello{
        TextView idTv,titileTv,singerTv,timeTv;
    }
}