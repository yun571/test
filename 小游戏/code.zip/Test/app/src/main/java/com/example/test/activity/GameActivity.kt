package com.example.test.activity

import android.animation.Animator
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.content.DialogInterface
import android.graphics.Matrix
import android.icu.text.SimpleDateFormat
import android.media.MediaPlayer
import android.media.MediaPlayer.SEEK_CLOSEST
import android.os.*
import android.util.Log
import android.view.View
import android.view.animation.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.test.R
import com.example.test.dialog.SettlementDialog
import com.example.test.listener.HomeListener
import com.example.test.listener.ScreenListener
import com.example.test.model.Block
import com.example.test.model.Data
import com.example.test.model.MusicInfo
import com.example.test.model.Record
import com.example.test.utils.CommonUtils
import com.example.test.utils.SharedPre
import kotlinx.android.synthetic.main.activity_game.*
import kotlinx.android.synthetic.main.settlementdialog.*
import org.litepal.LitePal
import org.litepal.extension.deleteAll
import org.litepal.extension.findAll
import org.litepal.extension.isExist
import org.litepal.model.Table_Schema
import java.io.IOException
import java.util.*
import kotlin.collections.ArrayList
import kotlin.math.absoluteValue
import kotlin.math.min


class GameActivity : AppCompatActivity(), View.OnClickListener {


    private var loadBlockPositionFlag = false
    private var blockQueue: Queue<Block> = LinkedList()    //待消除方块队列
    var timeCount: Int = 20     //总时间（秒）
    private var min: Int = 0            //分
    private var sec: Int = 0            //秒
    private var blockW = 0              //箭头的宽度
    private var blockH = 0              //箭头的高度
    private var blockLeft = 0
    private var blockTop = 0
    private var blockRight = 0
    private var blockBottom = 0
    private var stageW = 0              //stage的宽度
    private var stageH = 0              //stage的高度
    private var barrierW = 0            //barrier的宽度
    private var barrierH = 0            //barrier的宽度
    private var barrierL = 0
    private var barrierR = 0
    private val viewList = ArrayList<View>()             //存放准备动画view

    //动画是否消失或结束状态标志
    private var animationFlag = false
    private val GAMEPREPARE_DRUTION = 1000L             //准备动画时间
    var score = 0                       //得分
    private lateinit var homeListener: HomeListener
    private lateinit var screenListener: ScreenListener

    //是否为block还原状态标志
    private var dataFlag: Boolean = false
    private var what = 1
    private var obj = "normal"
    private var pauseDialog: AlertDialog? = null
    private var settlementDialog: SettlementDialog? = null
    var reloadDialog: AlertDialog? = null

    //准备动画是否结束标志
    private var preFlag = true

    //暂停状态标志
    private var pauseFlag = false

    //保存音效的数组
    private val musicResArray = arrayOf(
        R.raw.button_sound,
        R.raw.button_sound,
        R.raw.button_sound,
        R.raw.button_sound,
        R.raw.button_sound
    )

    //block是否可见标志
    private var visibilityFlag = false

    //准备动画是否可见标志
    private var preVisibilityFlag = false

    //重新加载状态标志
    private var reLoadFlag = false

    private var timeMills = 0L

    //音乐bean类
    private var musicInfo: MusicInfo? = null
    private var mediaPlayer: MediaPlayer? = null

    private var interpolatedTime = 0f

    /**
     * handler事件处理
     */
    private val handler = @SuppressLint("HandlerLeak")
    object : Handler() {
        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)
            when (msg.what) {
                1 -> {
                    Log.d("obj3==>", obj)
                    Log.d("obj2＿msg.obj==>", msg.obj.toString())
                    when (msg.obj.toString()) {
                        "pause" -> {
                            Log.d("obj4_pause==>", obj)
                            if (blockQueue.isNotEmpty() && timeCount > 0) {
                                min = timeCount / 60
                                sec = timeCount % 60
                                time_min.text = min.toString()
                                time_sec.text = sec.toString()
                            }
                        }
                        "normal" -> {
                            if (obj != "pause") {
                                Log.d("obj5_normal==>", obj)
                                if (blockQueue.isNotEmpty() && timeCount > 0) {
                                    timeCount--
                                    min = timeCount / 60
                                    sec = timeCount % 60
                                    time_min.text = min.toString()
                                    time_sec.text = sec.toString()
                                    val mmsg = Message()
                                    mmsg.what = what
                                    mmsg.obj = obj
                                    sendMessageDelayed(mmsg, 1000)
                                    Log.d("obj_handler", mmsg.obj.toString())
                                } else if (blockQueue.isEmpty() || timeCount <= 0) {
                                    //计时结束--->显示结算dialog
                                    if (!this@GameActivity.isFinishing) {
                                        block.clearAnimation()
                                        Log.d("poll_end1", blockQueue.size.toString())
                                        animationFlag = false
                                        blockQueue.clear()
                                        settlementDialog = SettlementDialog(
                                            this@GameActivity,
                                            R.style.settlementDialog
                                        )
                                        settlementDialog!!.setCancelable(false)
                                        val userRank = getRank(score)
                                        settlementDialog!!.show()
                                        stopMusic()
                                        mediaPlayer!!.release()
                                        SharedPre.saveDataFlag(this@GameActivity, false)
                                        visibilityFlag = false
                                        settlementDialog!!.score.text = score.toString()
                                        if (userRank == 6) {
                                            settlementDialog!!.rank.text =
                                                resources.getString(R.string.RANK)
                                        } else {
                                            settlementDialog!!.rank.text = userRank.toString()
                                        }
                                        settlementDialog!!.setYesOnclickListener(object :
                                            SettlementDialog.onYesOnclickListener {
                                            override fun onYesClick() {
                                                val username =
                                                    settlementDialog!!.name.text.toString()
                                                saveRecord(score, username, userRank)
                                                settlementDialog!!.dismiss()
                                                visibilityFlag = true
                                                this@GameActivity.finish()
                                            }
                                        })
                                        settlementDialog!!.setNoOnclickListener(object :
                                            SettlementDialog.onNoOnclickListener {
                                            override fun onNoClick() {
                                                val username =
                                                    settlementDialog!!.name.text.toString()
                                                saveRecord(score, username, userRank)
                                                settlementDialog!!.dismiss()
                                                visibilityFlag = true
                                                this@GameActivity.recreate()
                                            }
                                        })
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * 获取当前分数排名
     * @param score 分数
     * @return Int 排名
     */
    fun getRank(score: Int): Int {
        var allScore = ArrayList<Record>()
        val record = Record(score, 6, "")
        if (LitePal.isExist<Table_Schema>("name = ?", "record")) {
            allScore = LitePal.findAll<Record>() as ArrayList<Record>
        }
        allScore.add(record)
        //排序从大到小
        for (i in 0 until allScore.size) {
            for (j in 0 until allScore.size - 1 - i) {
                if (allScore[j].score < allScore[j + 1].score) {
                    var tmp = allScore[j]
                    allScore[j] = allScore[j + 1]
                    allScore[j + 1] = tmp
                }
            }
        }
        for (i in 0 until allScore.size) {
            allScore[i].ranking = i + 1
        }
        val index = allScore.indexOf(record)
        return allScore[index].ranking
    }

    /**
     * 保存排行榜信息
     * @param userScore 分数
     * @param userName 玩家姓名
     * @param userRank 排名
     */
    fun saveRecord(userScore: Int, userName: String, userRank: Int) {
        val record = Record(userScore, userRank, userName)

        if (LitePal.isExist<Table_Schema>("name = ?", "record")) {
            val allScore = LitePal.findAll<Record>()
            Log.d("allScore_size_1", allScore.size.toString())
            Log.d("allScore_1", allScore.toString())
            LitePal.deleteAll<Record>()
            allScore.add(record)
            //排序从大到小
            for (i in 0 until allScore.size) {
                for (j in 0 until allScore.size - 1 - i) {
                    if (allScore[j].score < allScore[j + 1].score) {
                        var tmp = allScore[j]
                        allScore[j] = allScore[j + 1]
                        allScore[j + 1] = tmp
                    }
                }
            }
            Log.d("allScore_size_2", allScore.size.toString())
            Log.d("allScore_2", allScore.toString())
            if (allScore.size > 5) {
                allScore.removeAt(allScore.size - 1)
            }
            for (i in 0 until allScore.size) {
                allScore[i].clearSavedState()
                allScore[i].ranking = i + 1
            }
            LitePal.saveAll(allScore)
            Log.d("allScore_3", allScore.toString())
        } else {
            record.save()
        }
    }

    //暂停Dialog
    private fun pauseMyDialog() {

        val builder = AlertDialog.Builder(this@GameActivity)
            .setIcon(R.mipmap.ic_launcher)
            .setTitle(getString(R.string.PAUSE))
            .setMessage(getString(R.string.CONTINUE))
            .setPositiveButton(
                getString(R.string.YES),
                object : DialogInterface.OnClickListener {
                    @RequiresApi(Build.VERSION_CODES.O)
                    override fun onClick(p0: DialogInterface?, p1: Int) {
                        pauseFlag = false
                        val data = SharedPre.getGameData(this@GameActivity)
                        Log.d("dataMusic", data.musicInfo.toString())
                        blockQueue = data.blockQueue
                        musicInfo = data.musicInfo
                        Log.d("blockQueue4", blockQueue.toString())
                        if (viewList.isNotEmpty()) {
                            container.addView(preImage_1)
                            container.addView(preImage_2)
                            container.addView(preImage_3)
                            gamePrepare(viewList[viewList.size - 1])
                        } else {
                            Log.d("blockQueue_else", blockQueue.toString())
                            if (blockQueue.isNotEmpty() && timeCount >= 0) {
                                //恢复游戏
                                resumeGame(data)
                            } else if (blockQueue.isEmpty()) {
                                val mmsg = Message()
                                obj = "normal"
                                mmsg.what = what
                                mmsg.obj = obj
                                handler.sendMessageDelayed(mmsg, 1000)
                            }
                        }
                    }
                })
            .setNegativeButton(
                getString(R.string.NO),
                object : DialogInterface.OnClickListener {
                    override fun onClick(p0: DialogInterface?, p1: Int) {
                        this@GameActivity.finish()
                    }
                })
            .setCancelable(false)
        if (reloadDialog == null || !reloadDialog!!.isShowing) {
            if (settlementDialog == null || !settlementDialog!!.isShowing) {
                pauseDialog = builder.create()
                pauseDialog!!.show()
                visibilityFlag = true
                pauseDialog!!.setOnDismissListener {
                    Log.d("pauseDialog", "setOnDismissListener")
                }
            }
        }
    }

    /**
     * 恢复游戏
     * @param data 游戏恢复数据
     */
    @RequiresApi(Build.VERSION_CODES.O)
    private fun resumeGame(data: Data) {
        resumeMusic(musicInfo!!)
        //重启计时器
        val mmsg = Message()
        obj = "normal"
        mmsg.what = what
        mmsg.obj = obj
        handler.sendMessageDelayed(mmsg, 1000)
        Log.d("obj_handler_dialogPos", mmsg.obj.toString())
        val bl = blockQueue.peek()
//        bl.speed = if (data.blockPos[0] > 0) {
//            (bl.speed * (data.blockPos[0] / blockLeft)).toInt().absoluteValue
//        } else {
//            (bl.speed * ((blockW + data.blockPos[0]) / blockLeft)).toInt().absoluteValue
//        }

        bl.speed -= (bl.speed * interpolatedTime).toInt()
        Log.d("dataPos[2]", data.blockPos[2].toString())
        blockAnimation(
            bl,
            0f,
            -data.blockPos[2],
            0f,
            0f
        )
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("TAG", "onCreate")
        setContentView(R.layout.activity_game)
        CommonUtils.getLanguage(this, "CHINESE")
        musicInfo = intent.getSerializableExtra("musicInfo") as MusicInfo
        val timeList = musicInfo!!.time!!.split(":")
        timeCount = timeList[0].toInt() * 60 + timeList[1].toInt()
        mediaPlayer = MediaPlayer()

        //val intent3 = Intent(this, MusicService(musicInfo!!)::class.java)

        val data = SharedPre.getGameData(this)
        reLoadFlag = data.dataFlag
        if (reLoadFlag) {
            time_min.text = "0"
            time_sec.text = "00"
            val builder = AlertDialog.Builder(this)
                .setIcon(R.mipmap.ic_launcher)
                .setTitle(getString(R.string.RELOAD))
                .setMessage(getString(R.string.reload))
                .setPositiveButton(
                    getString(R.string.YES),
                    object : DialogInterface.OnClickListener {
                        override fun onClick(p0: DialogInterface?, p1: Int) {
                            reLoadData(data)
                            viewList.add(preImage_1)
                            viewList.add(preImage_2)
                            viewList.add(preImage_3)
                            gamePrepare(viewList[viewList.size - 1])
                        }
                    }
                )
                .setNegativeButton(getString(R.string.NO),
                    object : DialogInterface.OnClickListener {
                        override fun onClick(p0: DialogInterface?, p1: Int) {
                            reLoadFlag = false
                            initBlock()
                            min = timeCount / 60
                            sec = timeCount % 60
                            time_min.text = min.toString()
                            time_sec.text = sec.toString()
                            viewList.add(preImage_1)
                            viewList.add(preImage_2)
                            viewList.add(preImage_3)
                            gamePrepare(viewList[viewList.size - 1])
                        }
                    })
            reloadDialog = builder.create()
            reloadDialog!!.show()
            visibilityFlag = false
            reloadDialog!!.setCancelable(false)
        } else {
            initBlock()
            min = timeCount / 60
            sec = timeCount % 60
            time_min.text = min.toString()
            time_sec.text = sec.toString()
            viewList.add(preImage_1)
            viewList.add(preImage_2)
            viewList.add(preImage_3)
            gamePrepare(viewList[viewList.size - 1])
        }


        //设置监听
        top_button.setOnClickListener(this)
        bottom_button.setOnClickListener(this)
        left_button.setOnClickListener(this)
        right_button.setOnClickListener(this)

        top_button.isClickable = false
        bottom_button.isClickable = false
        left_button.isClickable = false
        right_button.isClickable = false

    }

    override fun onStart() {
        super.onStart()
        Log.d("TAG", "onStart")
    }

    override fun onBackPressed() {
        Log.d("timeMills_onBackPressed", AnimationUtils.currentAnimationTimeMillis().toString())
        super.onBackPressed()
    }

    override fun onUserLeaveHint() {
        Log.d("timeMills_leave", AnimationUtils.currentAnimationTimeMillis().toString())
        super.onUserLeaveHint()
    }

    override fun onResume() {
        super.onResume()
        if (loadBlockPositionFlag) {
            val data = SharedPre.getGameData(this@GameActivity)
            block.layout(
                data.blockPos[0].toInt(),
                data.blockPos[1].toInt(),
                data.blockPos[2].toInt(),
                data.blockPos[3].toInt()
            )
        }
        Log.d("TAG", "onResume")
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    override fun onPause() {
        timeMills = min(AnimationUtils.currentAnimationTimeMillis(), SystemClock.uptimeMillis())
        if (block.animation != null) {
            interpolatedTime = block.animation.interpolator
                .getInterpolation(
                    ((timeMills.toFloat()
                            - (block.animation.startTime.toFloat()
                            + block.animation.startOffset))
                            / block.animation.duration.toFloat())
                )
        }


        if (reloadDialog == null || !reloadDialog!!.isShowing) {
            if (settlementDialog == null) {
                //暂停音乐
                pauseMusic()
            }
            preFlag = false
            pauseFlag = true
            //暂停计时器
            val mmsg = Message()
            obj = "pause"
            mmsg.what = what
            mmsg.obj = obj
            handler.sendMessageDelayed(mmsg, 0)
            Log.d("obj_handler_pauseTime", mmsg.obj.toString())
            //保存进度信息
            saveGameData(timeMills)
        }
        Log.d("TAG", "onPause")
        super.onPause()
    }


    @RequiresApi(Build.VERSION_CODES.N)
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
//        Log.d("timeMills",(AnimationUtils.currentAnimationTimeMillis()-timeMills).toString())
//        //保存进度信息
//        saveGameData(timeMills)
        Log.d("TAG", "onSaveInstanceState")
    }

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onStop() {
        super.onStop()
        if (pauseDialog != null && pauseDialog!!.isShowing) {
            pauseDialog!!.dismiss()
            visibilityFlag = false
        }
        Log.d("poll_onStop", blockQueue.size.toString())
        Log.d("TAG", "onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("TAG", "onDestroy")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("blockQueue1==>", blockQueue.toString())

        Log.d("block_left_2", block.left.toString())
        Log.d("block_top_2", block.top.toString())
        Log.d("block_right_2", block.right.toString())
        Log.d("block_bottom_2", block.bottom.toString())

        blockQueue.clear()
        Log.d("obj1==>", obj)
        if (timeCount >= 0 && reloadDialog == null || !reloadDialog!!.isShowing) {
            if (viewList.isNotEmpty()) {
                Log.d("viewList.size1", viewList.size.toString())
                for (i in viewList) {
                    container.removeView(i)
                }
                viewList.clear()
                viewList.add(preImage_1)
                viewList.add(preImage_2)
                viewList.add(preImage_3)
                Log.d("viewList.size2", viewList.size.toString())
                score_hint.visibility = View.INVISIBLE
                score_colon.visibility = View.INVISIBLE
                score_data.visibility = View.INVISIBLE
                preFlag = true
            }
            pauseMyDialog()
            if (visibilityFlag && preVisibilityFlag) {
                block.visibility = View.VISIBLE
            } else {
                block.visibility = View.INVISIBLE
            }
            if (reLoadFlag) {
                block.visibility = View.VISIBLE
            }
        }
        Log.d("TAG", "onRestart")
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        Log.d("TAG", "onAttachedToWindow")
    }


    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        Log.d("TAG", "onWindowFocusChanged")
        if (hasFocus) {
            if (reLoadFlag) {
                val data = SharedPre.getGameData(this)
                when (data.blockQueue.peek().direction) {
                    0 -> block.setImageResource(R.drawable.ic_arrow_up_24dp)
                    1 -> block.setImageResource(R.drawable.ic_arrow_down_24dp)
                    2 -> block.setImageResource(R.drawable.ic_arrow_left_24dp)
                    3 -> block.setImageResource(R.drawable.ic_arrow_right_24dp)
                }
                block.visibility = View.VISIBLE
                block.layout(
                    data.blockPos[0].toInt(),
                    data.blockPos[1].toInt(),
                    data.blockPos[2].toInt(),
                    data.blockPos[3].toInt()
                )
            }
        }
    }

    //游戏准备动画
    private fun gamePrepare(v: View?) {
        val set = AnimatorSet()
        if (v != null) {
            v.visibility = View.VISIBLE
            val scale1 = ObjectAnimator.ofFloat(v, "scaleX", 1f, 0f)
            val scale2 = ObjectAnimator.ofFloat(v, "scaleY", 1f, 0f)
            set.play(scale1).with(scale2)
            //set.playTogether(Scale1,Scale2)
            set.duration = GAMEPREPARE_DRUTION
            set.start()
        }

        set.addListener(object : Animator.AnimatorListener {
            override fun onAnimationRepeat(p0: Animator?) {
            }

            @RequiresApi(Build.VERSION_CODES.O)
            override fun onAnimationEnd(p0: Animator?) {

                if (!pauseFlag) {
                    //删除动画结束后的imageView
                    container.removeView(v)
                    viewList.remove(v)
                }

                if (viewList.isEmpty()) {
                    preFlag = false
                    preVisibilityFlag = true
                }
                Log.d("size", viewList.size.toString())
                Log.d("preFlag", preFlag.toString())

                if (reLoadFlag && viewList.isEmpty()) {
                    initPreData()
                    val data = SharedPre.getGameData(this@GameActivity)
                    //恢复游戏
                    resumeGame(data)
                } else {
                    if (viewList.size > 0 && !pauseFlag && preFlag) {
                        gamePrepare(viewList[viewList.size - 1])
                    } else if (!preFlag && !pauseFlag && viewList.size <= 0) {
                        //播放音乐
                        playMusic(musicInfo!!.path!!)
                        //当activity加载完毕后获取block、stage和barrier的宽高
                        // if (this@GameActivity.hasWindowFocus()) {
                        initPreData()
                        //启动计时
                        obj = "normal"
                        val mmsg = Message()
                        mmsg.what = what
                        mmsg.obj = obj
                        handler.sendMessageDelayed(mmsg, 0)
                        Log.d("obj_handler_gamePre", mmsg.obj.toString())
                        block.visibility = View.VISIBLE
                        if (blockQueue.isNotEmpty()) {
                            //开始箭头动画
                            blockAnimation(
                                blockQueue.peek()!!,
                                blockW.toFloat(),
                                -blockRight.toFloat(),
                                0f,
                                0f
                            )
                        }
                    }
                }
                Log.d("TAG", "pre_onAnimationEnd()")
            }

            override fun onAnimationCancel(p0: Animator?) {

            }

            override fun onAnimationStart(p0: Animator?) {
                Log.d("TAG", "pre_onAnimationStart()")
                preVisibilityFlag = false
            }

        })
    }

    /**
     * 初始化数据
     */
    private fun initPreData() {
        blockW = block.width
        blockH = block.height
        if (!reLoadFlag) {
            blockLeft = block.left
            blockTop = block.top
            blockRight = block.right
            blockBottom = block.bottom
            val initBlockData = ArrayList<Int>()
            initBlockData.add(blockLeft)
            initBlockData.add(blockTop)
            initBlockData.add(blockRight)
            initBlockData.add(blockBottom)
            SharedPre.saveInitBlockData(this, initBlockData)
        } else {
            val initBlockData = SharedPre.getInitBlockData(this)
            blockLeft = initBlockData[0]
            blockTop = initBlockData[1]
            blockRight = initBlockData[2]
            blockBottom = initBlockData[3]
        }
        stageW = stage.width
        stageH = stage.height

        barrierW = barrier.width
        barrierH = barrier.height

        barrierL = barrier.left
        barrierR = barrier.right

        Log.d("block_w==>", blockW.toString())
        Log.d("block_h==>", blockH.toString())
        Log.d("stage_w==>", stageW.toString())
        Log.d("stage_h==>", stageH.toString())
        Log.d("barrier_w==>", barrierW.toString())
        Log.d("barrier_h==>", barrierH.toString())
        Log.d("barrier_L==>", barrierL.toString())
        Log.d("barrier_R==>", barrierR.toString())
        Log.d("blockLeft", block.left.toString())
        Log.d("blockTop", block.top.toString())
        Log.d("blockRight", block.right.toString())
        Log.d("blockBottom", block.bottom.toString())
        //      }
        //设置按钮可点击
        top_button.isClickable = true
        bottom_button.isClickable = true
        left_button.isClickable = true
        right_button.isClickable = true
        //设置分数可见
        score_hint.visibility = View.VISIBLE
        score_colon.visibility = View.VISIBLE
        score_data.visibility = View.VISIBLE
    }

    //舞台动画实现
    private fun blockAnimation(
        bk: Block,
        fromX: Float,
        toX: Float,
        fromY: Float,
        toY: Float
    ) {
        var duration = 0L
        duration = bk.speed.toLong()      //动画时间
//        duration = 10000L      //动画时间

        Log.d("fromX==>", fromX.toString())
        Log.d("fromY==>", fromY.toString())

        // 平移动画
        val translate = TranslateAnimation(fromX, toX, fromY, toY)
        translate.duration = duration
        //translate.repeatMode = Animation.RESTART
        //重复动画
        //translate.repeatCount = Animation.INFINITE
        //透明度动画
        val alpha = AlphaAnimation(1.0f, 0.0f)
        alpha.duration = duration
        //alpha.repeatMode = Animation.RESTART
        //重复动画
        //alpha.repeatCount = Animation.INFINITE

        val animationSet = AnimationSet(true)
        animationSet.addAnimation(translate)

        //animationSet.addAnimation(alpha)
        block.startAnimation(translate)

        //设置平移动画的监听事件
        translate.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationRepeat(p0: Animation?) {

            }

            override fun onAnimationEnd(p0: Animation?) {
                Log.d("TAG", "onAnimationEnd()")
                Log.d("blockQueue2==>", blockQueue.toString())
                if (block.animation != null) {
                    val dis = getFinalDistance(
                        block.animation,
                        AnimationUtils.currentAnimationTimeMillis()
                    )
                    Log.d("dis_animation", dis.toString())
                    block.animation = null
                }
                Log.d("time_3", AnimationUtils.currentAnimationTimeMillis().toString())
                Log.d("time_4", SystemClock.uptimeMillis().toString())
                //block.clearAnimation()
                block.visibility = View.INVISIBLE

                Log.d("pauseFlag", pauseFlag.toString())
                if (!pauseFlag) {
                    block.layout(blockLeft, blockTop, blockRight, blockBottom)
                    loadBlockPositionFlag = false
                } else {
                    loadBlockPositionFlag = true
//                    val data = SharedPre.getGameData(this@GameActivity)
//                    block.layout(
//                        data.blockPos[0].toInt(),
//                        data.blockPos[1].toInt(),
//                        data.blockPos[2].toInt(),
//                        data.blockPos[3].toInt()
//                    )
                }
                if (animationFlag) {
                    blockQueue.poll()
                }
                animationFlag = false
                Log.d("blockQueue3==>", blockQueue.toString())
                //正常结束
                if (blockQueue.isNotEmpty() && !pauseFlag) {
                    Log.d("TAG==>", "onAnimationEnd_animation")
                    //开始箭头动画
                    blockAnimation(
                        blockQueue.peek()!!,
                        blockW.toFloat(),
                        -blockRight.toFloat(),
                        0f,
                        0f
                    )
                    dataFlag = false
                } else if (blockQueue.isNotEmpty() && pauseFlag) {

                    //非正常结束
                    dataFlag = true
                }

                Log.d("dataFlag==>", dataFlag.toString())
            }

            override fun onAnimationStart(p0: Animation?) {
                Log.d(
                    "time__animation_Start",
                    AnimationUtils.currentAnimationTimeMillis().toString()
                )
                Log.d("time__system_Start", System.currentTimeMillis().toString())
                when (bk.direction) {
                    0 -> block.setImageResource(R.drawable.ic_arrow_up_24dp)
                    1 -> block.setImageResource(R.drawable.ic_arrow_down_24dp)
                    2 -> block.setImageResource(R.drawable.ic_arrow_left_24dp)
                    3 -> block.setImageResource(R.drawable.ic_arrow_right_24dp)
                }
                Log.d("TAG", "onAnimationStart()")
                block.visibility = View.VISIBLE
                animationFlag = true
                bk.alive = true
                if (timeCount == 0) {
                    block.clearAnimation()
                    animationFlag = false
                    block.visibility = View.INVISIBLE
                }
            }
        })
    }


    //初始化箭头队列
    private fun initBlock() {
        val num = timeCount
        val rand = Random()
        //blockQueue = LinkedList<Block>()
        for (i in 1..num) {
            val block = Block(rand.nextInt(4), (rand.nextInt(20) + 10) * 100)
//            val block = Block(0, 10000)
            Log.d("GameActivity", "direction===>" + block.direction)
            Log.d("GameActivity", "speed===>" + block.speed)
            blockQueue.offer(block)
        }
        Log.d("GameActivity", "num===>${blockQueue.size}")
    }

    /**
     * 判断方块方向是否一致
     * @param block_direction 箭头的方向
     * @param button_direction 按钮的方向
     * @return Boolean
     */
    private fun matchingBlock(block_direction: Int, button_direction: Int): Boolean {
        return block_direction == button_direction
    }

    //按钮点击事件处理
    override fun onClick(v: View?) {
        if (blockQueue.isNotEmpty() && animationFlag) {
            when (v) {
                top_button -> {
                    //正确消除,与箭头方向一致
                    Log.d("b_size", blockQueue.size.toString())
                    //正确消除箭头
                    if (matchingBlock(blockQueue.peek().direction, 0)) {
                        //计算成绩
                        val tmp = score(blockW / 2)
                        //正确消除箭头反馈处理
                        btnClickRight(tmp)
                    }
                }
                bottom_button -> {
                    //正确消除,与箭头方向一致
                    if (matchingBlock(blockQueue.peek().direction, 1)) {
                        //计算成绩
                        val tmp = score(blockW / 2)
                        //正确消除箭头反馈处理
                        btnClickRight(tmp)
                    }
                }
                left_button -> {
                    //正确消除,与箭头方向一致
                    if (matchingBlock(blockQueue.peek().direction, 2)) {
                        //计算成绩
                        val tmp = score(blockW / 6)
                        //正确消除箭头反馈处理
                        btnClickRight(tmp)
                    }
                }
                right_button -> {
                    //正确消除,与箭头方向一致
                    if (matchingBlock(blockQueue.peek().direction, 3)) {
                        //计算成绩
                        val tmp = score(blockW - blockW / 6)
                        //正确消除箭头反馈处理
                        btnClickRight(tmp)
                    }
                }
            }
        }
    }

    /**
     * 正确消除箭头后,进行的处理
     * @param tmp 获得的分数
     */
    private fun btnClickRight(tmp: Int) {
        //播放提示音
        playSound(this, musicResArray, tmp)
        //计算成绩
        score += tmp
        score_data.text = score.toString()

        //blockQueue.poll()
        block.clearAnimation()
        animationFlag = false
        //stage.removeView(block)
        Log.d("GameActivity", "num===>${blockQueue.size}")
        if (blockQueue.isNotEmpty()) {
            //开始箭头动画
            blockAnimation(
                blockQueue.peek()!!,
                blockW.toFloat(),
                -blockRight.toFloat(),
                0f,
                0f
            )
        } else {
            block.visibility = View.INVISIBLE
        }
    }


    /**
     * 计算成绩
     *@param offset 箭头尖顶位置与左边界的偏移值
     *@return Int 分数
     */
    private fun score(offset: Int): Int {
        var finalDistance = 0f
        val timeMillis = AnimationUtils.currentAnimationTimeMillis()
        if (block.animation != null && !dataFlag) {
            finalDistance = if (getFinalDistance(block.animation, timeMillis) < 0) {
                getFinalDistance(block.animation, timeMillis).absoluteValue + blockW
            } else {
                blockW - getFinalDistance(block.animation, timeMillis)
            }
        } else if (block.animation != null && dataFlag) {
            val data = SharedPre.getGameData(this)
            finalDistance =
                getFinalDistance(
                    block.animation,
                    timeMillis
                ).absoluteValue + blockRight - data.blockPos[0]
        }
        Log.d("finalDistance==>", finalDistance.toString())
        return calculateScore(finalDistance - offset)
    }

    /**
     * 成绩分段设置
     * @param finalDistance 箭头在X轴所移动的的距离(px)
     * @return Int 分数
     */
    private fun calculateScore(finalDistance: Float): Int {
        var score = 0
        val distance = blockRight - finalDistance
        val dataRange = (distance - barrierL - barrierW / 2).absoluteValue
        Log.d("dataRange==>", dataRange.toString())
        score = if (0 <= dataRange && 16 > dataRange) {
            50
        } else if (16 <= dataRange && 31 > dataRange) {
            30
        } else if (31 <= dataRange && 51 > dataRange) {
            15
        } else if (51 <= dataRange && 81 > dataRange) {
            5
        } else {
            0
        }
        Log.d("dataScore==>", score.toString())
        return score
    }

    /**
     * 获取animation的移动距离
     * @param animation 动画
     * @param currentAnimationTimeMillis 当前动画运行的时间点
     * @return Float 动画当前时间X轴移动的距离
     */
    private fun getFinalDistance(animation: Animation, currentAnimationTimeMillis: Long): Float {
        val transformation = Transformation()
        animation.getTransformation(
            currentAnimationTimeMillis,
            transformation
        )
        val matrix: Matrix = transformation.matrix
        //val matrix: Matrix? = block.animationMatrix
        val matrixVals = FloatArray(9)
        matrix.getValues(matrixVals)
        Log.d("distance==>", matrixVals[2].toString())
        return matrixVals[2]
    }


    /**
     * 记录block的最终位置
     */
    private fun blockPosition(
        left: Float,
        top: Float,
        right: Float,
        bottom: Float
    ): FloatArray {
        val array = FloatArray(4)
        //block的l,t,r,b
        array[0] = left
        array[1] = top
        array[2] = right
        array[3] = bottom
        return array
    }

    /**
     * 根据分数段来播放音效
     * @param context
     * @param musicResArray 音乐资源数组
     * @param score 分数
     */
    private fun playSound(context: Context, musicResArray: Array<Int>, score: Int) {
        when (score) {
            50 -> playSoundByResId(context, musicResArray[0])
            30 -> playSoundByResId(context, musicResArray[1])
            15 -> playSoundByResId(context, musicResArray[2])
            5 -> playSoundByResId(context, musicResArray[3])
            0 -> playSoundByResId(context, musicResArray[4])
        }
    }

    /**
     * 播放音效
     * @param context
     * @param musicId 资源ID
     */
    private fun playSoundByResId(context: Context, musicId: Int) {
        val music = MediaPlayer.create(context, musicId)
        music.start()
//        al uri: Uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) //系统自带提示音
//        val rt = RingtoneManager.getRingtone(applicationContext, uri)
//        rt.play()
    }

    /**
     * 重新加载数据
     * @param data 所需重新加载的数据
     */
    private fun reLoadData(data: Data) {
        dataFlag = true
        score = data.dataScore.toInt()
        score_data.text = score.toString()
        timeCount = data.timeCount
        blockQueue = data.blockQueue
        time_min.text = (timeCount / 60).toString()
        time_sec.text = (timeCount % 60).toString()
        musicInfo = data.musicInfo
    }

    /**
     *播放音乐
     * @param path 音乐路径
     */
    private fun playMusic(path: String) {
        if (mediaPlayer != null && !mediaPlayer!!.isPlaying) {
            mediaPlayer!!.setDataSource(path)
            try {
                mediaPlayer!!.prepare()
                mediaPlayer!!.start()
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    /**
     * 暂停播放音乐
     */
    private fun pauseMusic() {
        if (mediaPlayer != null) {
            mediaPlayer!!.pause()
        }
    }

    /**
     * 继续播放音乐
     * @param musicInfo 音乐Bean类
     */
    @RequiresApi(Build.VERSION_CODES.O)
    private fun resumeMusic(musicInfo: MusicInfo) {
        if (mediaPlayer != null && !mediaPlayer!!.isPlaying) {
            if (!reLoadFlag) {
                Log.d("path_1", musicInfo.path!!)
                // mediaPlayer!!.setDataSource(musicInfo.path)
                mediaPlayer!!.seekTo(musicInfo.time!!.toLong(), SEEK_CLOSEST)
                mediaPlayer!!.start()
            } else {
                reLoadFlag = false
                Log.d("path_2", musicInfo.path!!)
                mediaPlayer!!.reset()
                mediaPlayer!!.setDataSource(musicInfo.path)
                mediaPlayer!!.prepare()
                mediaPlayer!!.seekTo(musicInfo.time!!.toLong(), SEEK_CLOSEST)
                mediaPlayer!!.start()
            }
        }
    }

    /**
     *停止播放音乐
     */
    private fun stopMusic() {
        if (mediaPlayer != null) {
            mediaPlayer!!.stop()
        }
    }


    /**
     * 保存游戏进度
     */
    @RequiresApi(Build.VERSION_CODES.N)
    private fun saveGameData(time: Long) {
        var finalDistance: Float = 0f
        if (block.animation != null) {
            val dataFirst = SharedPre.getGameData(this)

            finalDistance = getFinalDistance(block.animation, time)
            // getFinalDistance(block.animation, AnimationUtils.currentAnimationTimeMillis())
            Log.d("timeMills", time.toString())
            Log.d("time_1", SystemClock.uptimeMillis().toString())
            block.visibility = View.INVISIBLE
            block.clearAnimation()
//            block.animation.cancel()
//            block.animation = null

            Log.d("time_2", AnimationUtils.currentAnimationTimeMillis().toString())
            animationFlag = false
            val bq: Queue<Block> = LinkedList()
            for (i in blockQueue) {
                bq.offer(i)
            }
            var blockPos: FloatArray
            val data: Data
            if (dataFlag) {
                    blockPos = blockPosition(
                    (dataFirst.blockPos[0].toInt() + finalDistance.toInt()).toFloat(),
                    dataFirst.blockPos[1].toInt().toFloat(),
                    (dataFirst.blockPos[2].toInt() + finalDistance.toInt()).toFloat(),
                    dataFirst.blockPos[3].toInt().toFloat()
                )
            } else {
                Log.d("distance onPause==>", finalDistance.toString())
                blockPos = blockPosition(
                    blockLeft.toFloat() + finalDistance.toInt(),
                    blockTop.toFloat(),
                    blockRight.toFloat() + finalDistance.toInt(),
                    blockBottom.toFloat()
                )
                //dataFlag = true
            }

            val sdf = SimpleDateFormat("mm:ss")
            Log.d("currentPosition", mediaPlayer!!.currentPosition.toString())
            //val time = sdf.format(Date( mediaPlayer!!.currentPosition.toString()))
            musicInfo!!.time = mediaPlayer!!.currentPosition.toString()

            data = Data(score_data.text.toString(), timeCount, true, blockPos, bq, musicInfo!!)
            for (i in data.blockPos) {
                Log.d("blockPos", i.toString())
            }
            Log.d("blockQueue_onPause==>", bq.toString())
            //保存进度
            SharedPre.saveGameData(this, data)
        }
    }
}